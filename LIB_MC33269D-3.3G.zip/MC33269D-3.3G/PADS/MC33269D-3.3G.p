*PADS-LIBRARY-PART-TYPES-V9*

MC33269D-3.3G SOIC127P600X175-8N I ANA 9 1 0 0 0
TIMESTAMP 2026.08.26.14.08.09
"Manufacturer_Name" onsemi
"Manufacturer_Part_Number" MC33269D-3.3G
"Mouser Part Number" 863-MC33269D-3.3G
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/onsemi/MC33269D-3.3G?qs=dFKnUM%2FquJZ%252BBcrN2hd5Yg%3D%3D
"Arrow Part Number" MC33269D-3.3G
"Arrow Price/Stock" https://www.arrow.com/en/products/mc33269d-3.3g/on-semiconductor?utm_currency=USD&region=europe
"Description" Output Current in Excess of 800 mA; 1.0 V Dropout; Short Circuit Protection; Output Trimmed to 1.0% Tolerance; Thermal Protection; 3.3 V, 5.0 V, 12 V and Adjustable Versions 2.85 V version available as MC34268.; Space Saving DPAK, SOP-8 and SOT-223 Power Packages; Pb-Free Packages are Available
"Datasheet Link" https://www.onsemi.com/pub/Collateral/MC33269-D.PDF
"Geometry.Height" 1.75mm
GATE 1 8 0
MC33269D-3.3G
1 0 U GND/ADJ
2 0 U VOUT_1
3 0 U VOUT_2
4 0 U VIN
8 0 U NC_2
7 0 U VOUT_4
6 0 U VOUT_3
5 0 U NC_1

*END*
*REMARK* SamacSys ECAD Model
225275/580309/2.50/8/2/Integrated Circuit
